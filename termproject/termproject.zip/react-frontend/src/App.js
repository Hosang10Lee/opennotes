import './App.css';
import React, { Fragment } from 'react';
import { BrowserRouter as Router, Link, Route, Routes } from 'react-router-dom';
import VideoPlayer from './components/VideoPlayer';
import Users from './components/Users';

function App() {
  return (
    <div className="App">
      {/* <header className="App-header">         */}
        <Fragment>
        <Router>
          <div>
          <Link to='/' className='link'>Home</Link>
            <Link to='/video' className='link'>Video</Link>
            <Link to='/users' className='link'>Users</Link>
          </div>
          <Routes>
            {/* <Route exact path='/video' element={<VideoPlayer src="https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8" />} /> */}
            <Route exact path='/video' element={<VideoPlayer src="https://cdn-vos-ppp-01.vos360.video/Content/HLS_HLSCLEAR/Live/channel(PPP-LL-2HLS)/index.m3u8" />} />
            <Route exact path='/users' element={<Users />} />
          </Routes>
        </Router>
        </Fragment>
      {/* </header> */}
    </div>
  );
}

export default App;
