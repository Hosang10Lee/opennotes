import React, { Component } from 'react';
import axios from 'axios';

class Users extends Component {
  constructor(props) {
    super(props);
    this.state = {
      users: [],
      name: '',
      email: ''
    };
  }

  componentDidMount() {
    this.fetchUsers();
  }

  fetchUsers = async () => {
    try {
      const response = await axios.get('/api/users');
      this.setState({ users: response.data })
      console.log('>>>>>> RESPONSE: ', response.data);
    } catch (error) {
      console.error(error);
    }
  };

  handleSubmit = e => {
    e.preventDefault();
    axios.post('/api/users', { name: this.state.name, email: this.state.email })
      .then(response => {
        this.setState(prevState => ({
          users: [...prevState.users, response.data],
          name: '',
          email: ''
        }));
      })
      .catch(error => console.error(error));
  };

  handleDelete = async id => {
    try {
      await axios.delete(`/api/users/${id}`);
      this.setState(prevState => ({
        users: prevState.users.filter(user => user._id !== id)
      }));
    } catch (error) {
      console.error(error);
    }
  };

  render() {
    const { users, name, email } = this.state;
    return (
      <div>
        <h2>User List</h2>
        {Array.isArray(users) ? (
          <ul>
            {users.map(user => (
              <li key={user._id}>
                {user.name} ({user.email})
                <button onClick={() => this.handleDelete(user._id)}>Delete</button>
              </li>
            ))}
          </ul>
        ) : (
          <p>Cannot retreive data!</p>
        )}
        <h2>Add User</h2>
        <form onSubmit={this.handleSubmit}>
          <input type="text" value={name} onChange={e => this.setState({ name: e.target.value })} placeholder="Name" />
          <input type="email" value={email} onChange={e => this.setState({ email: e.target.value })} placeholder="Email" />
          <button type="submit">Add User</button>
        </form>
      </div>
    );
  }
}

export default Users;