export const KEY_UP = 'keyup';
export const SCREEN_ORIENTATION_CHANGE = 'screenOrientationChange';
export const VISIBILITY_CHANGE = 'visibilitychange';
export const WEBOS_HIHG_CONTRAST_CHANGE = 'webOSHighContrastChange';
export const WEBOS_LOCALE_CHANGE = 'webOSLocaleChange';
export const WEBOS_RELAUNCH = 'webOSRelaunch';
