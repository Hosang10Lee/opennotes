#ifndef __SPEECH_RECOGNIZER_H__
#define __SPEECH_RECOGNIZER_H__

#include <glib.h>

typedef struct _SpeechRecognizerCallbacks
{
  /**
   * command: Callback to retrieve the detected speech commands.
   * @str: Detected speech command string
   */
  void (*command) (const gchar * str);
} SpeechRecognizerCallbacks;

gboolean speech_recognizer_init (const char *argv1);
void speech_recognizer_finalize ();
void speech_recognizer_install_callbacks (SpeechRecognizerCallbacks * callbacks,
    gpointer user_data);
void speech_recognizer_set_window_handle (guintptr handle);
void speech_recognizer_start ();

#endif /* __SPEECH_RECOGNIZER_H__ */
