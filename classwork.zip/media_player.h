#ifndef __MEDIA_PLAYER_H__
#define __MEDIA_PLAYER_H__

#include <glib.h>

typedef struct _MediaPlayerCallbacks
{
  /**
   * stream_info: Callback to retrieve stream information of the playback stream.
   * @str: Stream information string
   */
  void (*stream_info) (const gchar * str);
} MediaPlayerCallbacks;

gboolean media_player_init ();
void media_player_finalize ();
void media_player_install_callbacks (MediaPlayerCallbacks * callbacks,
    gpointer user_data);
void media_player_set_window_handle (guintptr handle);
gboolean media_player_playing_state ();
void media_player_play ();
void media_player_pause ();
void media_player_stop ();
void media_player_seek (gdouble value);
gint64 media_player_get_duration_ns ();
gint64 media_player_get_current_position_ns ();

#endif /* __MEDIA_PLAYER_H__ */
