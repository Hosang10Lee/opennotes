#include "media_player.h"

#include <gst/gst.h>
#include <gst/video/videooverlay.h>

typedef struct _PlayerPrivate
{
  GstElement *playbin;          /* Our one and only pipeline */

  GstState state;               /* Current state of the pipeline */
  gint64 duration;              /* Duration of the clip, in nanoseconds */
} PlayerPrivate;

static PlayerPrivate player;
static const MediaPlayerCallbacks *player_callbacks;

static void
tags_cb (GstElement * playbin, gint stream, gpointer data)
{
  /* We are possibly in a GStreamer working thread, so we notify the main
   * thread of this event through a message in the bus */
  gst_element_post_message (playbin,
      gst_message_new_application (GST_OBJECT (playbin),
          gst_structure_new_empty ("tags-changed")));
}

/* This function is called when an error message is posted on the bus */
static void
error_cb (GstBus * bus, GstMessage * msg, gpointer data)
{
  GError *err;
  gchar *debug_info;

  /* Print error details on the screen */
  gst_message_parse_error (msg, &err, &debug_info);
  g_printerr ("Error received from element %s: %s\n",
      GST_OBJECT_NAME (msg->src), err->message);
  g_printerr ("Debugging information: %s\n", debug_info ? debug_info : "none");
  g_clear_error (&err);
  g_free (debug_info);

  /* Set the pipeline to READY (which stops playback) */
  gst_element_set_state (player.playbin, GST_STATE_READY);
}

/* This function is called when an End-Of-Stream message is posted on the bus.
 * We just set the pipeline to READY (which stops playback) */
static void
eos_cb (GstBus * bus, GstMessage * msg, gpointer data)
{
  g_print ("End-Of-Stream reached.\n");
  gst_element_set_state (player.playbin, GST_STATE_READY);
}

/* This function is called when the pipeline changes states. We use it to
 * keep track of the current state. */
static void
state_changed_cb (GstBus * bus, GstMessage * msg, gpointer data)
{
  // TODO-09

}

static void
analyze_streams ()
{
  gint i;
  GstTagList *tags = NULL;
  gchar *str = NULL;
  gchar *total_str = NULL;
  guint rate;
  gint n_video, n_audio, n_text;
  GString *info_string = g_string_new ("");

  /* Read some properties */
  g_object_get (player.playbin, "n-video", &n_video, NULL);
  g_object_get (player.playbin, "n-audio", &n_audio, NULL);
  g_object_get (player.playbin, "n-text", &n_text, NULL);

  for (i = 0; i < n_video; i++) {
    tags = NULL;
    /* Retrieve the stream's video tags */
    g_signal_emit_by_name (player.playbin, "get-video-tags", i, &tags);
    if (tags) {
      total_str = g_strdup_printf ("video stream %d:\n", i);
      info_string = g_string_append (info_string, total_str);
      g_free (total_str);
      if (gst_tag_list_get_string (tags, GST_TAG_VIDEO_CODEC, &str)) {
        total_str = g_strdup_printf ("  codec: %s\n", str ? str : "unknown");
      } else {
        total_str = g_strdup_printf ("  codec: unknown\n");
      }
      
      info_string = g_string_append (info_string, total_str);
      g_free (total_str);
      if (str) g_free (str);
      str = NULL;
      gst_tag_list_free (tags);
    }
  }

  for (i = 0; i < n_audio; i++) {
    tags = NULL;
    /* Retrieve the stream's audio tags */
    g_signal_emit_by_name (player.playbin, "get-audio-tags", i, &tags);
    if (tags) {
      total_str = g_strdup_printf ("\naudio stream %d:\n", i);
      info_string = g_string_append (info_string, total_str);
      g_free (total_str);
      if (gst_tag_list_get_string (tags, GST_TAG_AUDIO_CODEC, &str)) {
        total_str = g_strdup_printf ("  codec: %s\n", str);
        info_string = g_string_append (info_string, total_str);
        g_free (total_str);
        g_free (str);
        str = NULL;
      }
      if (gst_tag_list_get_string (tags, GST_TAG_LANGUAGE_CODE, &str)) {
        total_str = g_strdup_printf ("  language: %s\n", str);
        info_string = g_string_append (info_string, total_str);
        g_free (total_str);
        g_free (str);
      }
      if (gst_tag_list_get_uint (tags, GST_TAG_BITRATE, &rate)) {
        total_str = g_strdup_printf ("  bitrate: %d\n", rate);
        info_string = g_string_append (info_string, total_str);
        g_free (total_str);
      }
      gst_tag_list_free (tags);
    }
  }
  if (player_callbacks && player_callbacks->stream_info) {
    player_callbacks->stream_info (info_string->str);
  }

  g_string_free (info_string, TRUE);
}

/* This function is called when an "application" message is posted on the bus.
 * Here we retrieve the message posted by the tags_cb callback */
static void
application_cb (GstBus * bus, GstMessage * msg, gpointer data)
{
  if (g_strcmp0 (gst_structure_get_name (gst_message_get_structure (msg)),
          "tags-changed") == 0) {
    /* If the message is the "tags-changed" (only one we are currently issuing), update
     * the stream info GUI */
    analyze_streams ();
  }
}

int
create_player ()
{
  GstStateChangeReturn ret;
  GstBus *bus;

  player.duration = GST_CLOCK_TIME_NONE;
  player.state = GST_STATE_NULL;

  // TODO-02


  /* Set the URI to play */


  // TODO-10


  // /* Instruct the bus to emit signals for each received message, and connect to the interesting signals */
  bus = gst_element_get_bus (player.playbin);
  gst_bus_add_signal_watch (bus);
  g_signal_connect (G_OBJECT (bus), "message::error", (GCallback) error_cb,
      NULL);
  g_signal_connect (G_OBJECT (bus), "message::eos", (GCallback) eos_cb, NULL);

  // TODO-09


  // TODO-11

  gst_object_unref (bus);

  return 0;
}

gboolean
media_player_init ()
{
  gst_init (NULL, NULL);

  if (create_player ()) {
    return FALSE;
  }

  return TRUE;
}

void
media_player_finalize ()
{
  /* Free resources */
  gst_element_set_state (player.playbin, GST_STATE_NULL);
  gst_object_unref (player.playbin);
}

void
media_player_install_callbacks (MediaPlayerCallbacks * callbacks,
    gpointer user_data)
{
  player_callbacks = callbacks;
}

void
media_player_set_window_handle (guintptr handle)
{
  gst_video_overlay_set_window_handle (GST_VIDEO_OVERLAY (player.playbin),
      handle);
}

gboolean
media_player_playing_state ()
{
  if (player.state < GST_STATE_PAUSED)
    return FALSE;

  return TRUE;
}

void
media_player_play ()
{
  // TODO-03

}

void
media_player_pause ()
{
  // TODO-05

}

void
media_player_stop ()
{
  // TODO-07

}

void
media_player_seek (gdouble value)
{
  // TODO-16

}

gint64
media_player_get_duration_ns ()
{
  gint64 duration = -1;

  // TODO-13


  return duration;
}

gint64
media_player_get_current_position_ns ()
{
  gint64 current = -1;

  // TODO-14


  return current;
}
