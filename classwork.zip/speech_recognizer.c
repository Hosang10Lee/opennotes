#include "speech_recognizer.h"

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#include <gst/gst.h>
#include <gst/video/videooverlay.h>

#define DBG TRUE
#ifndef DBG
#define DBG FALSE
#endif

/**
 * @brief Macro for debug message.
 */
#define _print_log(...) if (DBG) g_message (__VA_ARGS__)

/**
 * @brief Macro to check error case.
 */
#define _check_cond_err(cond) \
  do { \
    if (!(cond)) { \
      _print_log ("speech recognizer failed! [line : %d]", __LINE__); \
      goto error; \
    } \
  } while (0)

/**
 * @brief Data structure for tflite model info.
 */
typedef struct
{
  gchar *model_path; /**< tflite model file path */
  gchar *label_path; /**< label file path */
  GSList *labels; /**< list of loaded labels */
  guint total_labels; /**< count of labels */
} tflite_info_s;

/**
 * @brief Data structure for app.
 */
typedef struct _RecognizerPrivate
{
  GstElement *pipeline; /**< gst pipeline for data stream */
  GstBus *bus; /**< gst bus for data pipeline */
  guint timer_id;
  gboolean running; /**< true when app is running */
  gint current_label_index; /**< current label index */
  gint new_label_index; /**< new label index */
  tflite_info_s tflite_info; /**< tflite model info */
  guintptr win_handle;
} RecognizerPrivate;

static RecognizerPrivate recognizer;
static SpeechRecognizerCallbacks *recognizer_callbacks;

/**
 * @brief Free data in tflite info structure.
 */
static void
tflite_free_info (tflite_info_s * tflite_info)
{
  g_return_if_fail (tflite_info != NULL);

  if (tflite_info->model_path) {
    g_free (tflite_info->model_path);
    tflite_info->model_path = NULL;
  }

  if (tflite_info->label_path) {
    g_free (tflite_info->label_path);
    tflite_info->label_path = NULL;
  }

  if (tflite_info->labels) {
    g_slist_free_full (tflite_info->labels, g_free);
    tflite_info->labels = NULL;
  }
}

/**
 * @brief Check tflite model and load labels.
 */
static gboolean
tflite_init_info (tflite_info_s * tflite_info, const gchar * path)
{
  const gchar tflite_model[] = "conv_actions_frozen.tflite";
  const gchar tflite_label[] = "conv_actions_labels.txt";

  FILE *fp;

  g_return_val_if_fail (tflite_info != NULL, FALSE);

  tflite_info->model_path = NULL;
  tflite_info->label_path = NULL;
  tflite_info->labels = NULL;

  /* check model file exists */
  tflite_info->model_path = g_strdup_printf ("%s/%s", path, tflite_model);

  if (access (tflite_info->model_path, F_OK) != 0) {
    g_critical ("cannot find tflite model [%s]", tflite_info->model_path);
    return FALSE;
  }

  /* load labels */
  tflite_info->label_path = g_strdup_printf ("%s/%s", path, tflite_label);

  if ((fp = fopen (tflite_info->label_path, "r")) != NULL) {
    char *line = NULL;
    size_t len = 0;
    ssize_t read;
    gchar *label;

    while ((read = getline (&line, &len, fp)) != -1) {
      label = g_strdup ((gchar *) line);
      tflite_info->labels = g_slist_append (tflite_info->labels, label);
    }

    if (line) {
      free (line);
    }

    fclose (fp);
  } else {
    g_critical ("cannot find tflite label [%s]", tflite_info->label_path);
    return FALSE;
  }

  tflite_info->total_labels = g_slist_length (tflite_info->labels);
  _print_log ("finished to load labels, total %d", tflite_info->total_labels);
  return TRUE;
}

/**
 * @brief Get label string with given index.
 */
static gchar *
tflite_get_label (tflite_info_s * tflite_info, gint index)
{
  guint length;

  g_return_val_if_fail (tflite_info != NULL, NULL);
  g_return_val_if_fail (tflite_info->labels != NULL, NULL);

  length = g_slist_length (tflite_info->labels);
  g_return_val_if_fail (index >= 0 && index < length, NULL);

  return (gchar *) g_slist_nth_data (tflite_info->labels, index);
}

/**
 * @brief Update tflite label index with max score.
 * @param scores array of scores
 * @param len received data length
 * @return None
 */
static void
update_top_label_index (float *scores, guint len)
{
  gint i;
  gint index = -1;
  float max_score = .0;

  g_return_if_fail (scores != NULL);
  g_return_if_fail ((len / sizeof (float)) ==
      recognizer.tflite_info.total_labels);

  for (i = 0; i < recognizer.tflite_info.total_labels; i++) {
    if (scores[i] > 0 && scores[i] > max_score) {
      index = i;
      // _print_log ("scores[%d] %f", i, scores[i]);
      max_score = scores[i];
    }
  }

  /* score threshold */
  // _print_log ("max score %f", max_score);
  if (max_score > 0.40f) {
    recognizer.new_label_index = index;
  }
}

/**
 * @brief Free resources in app data.
 */
static void
free_app_data (void)
{
  if (recognizer.timer_id > 0) {
    g_source_remove (recognizer.timer_id);
    recognizer.timer_id = 0;
  }
  // if (recognizer.bus) {
  //   gst_bus_remove_signal_watch (recognizer.bus);
  //   gst_object_unref (recognizer.bus);
  //   recognizer.bus = NULL;
  // }

  if (recognizer.pipeline) {
    gst_object_unref (recognizer.pipeline);
    recognizer.pipeline = NULL;
  }

  tflite_free_info (&recognizer.tflite_info);
}

/**
 * @brief Function to print error message.
 */
static void
parse_err_message (GstMessage * message)
{
  gchar *debug;
  GError *error;

  g_return_if_fail (message != NULL);

  switch (GST_MESSAGE_TYPE (message)) {
    case GST_MESSAGE_ERROR:
      gst_message_parse_error (message, &error, &debug);
      break;

    case GST_MESSAGE_WARNING:
      gst_message_parse_warning (message, &error, &debug);
      break;

    default:
      return;
  }

  gst_object_default_error (GST_MESSAGE_SRC (message), error, debug);
  g_error_free (error);
  g_free (debug);
}

/**
 * @brief Callback for message.
 */
static void
bus_message_cb (GstBus * bus, GstMessage * message, gpointer user_data)
{
  g_print ("BUS!!!\n");
  switch (GST_MESSAGE_TYPE (message)) {
    case GST_MESSAGE_EOS:
      _print_log ("received eos message");
      break;

    case GST_MESSAGE_ERROR:
      _print_log ("received error message");
      parse_err_message (message);
      break;

    case GST_MESSAGE_WARNING:
      _print_log ("received warning message");
      parse_err_message (message);
      break;

    case GST_MESSAGE_STREAM_START:
      _print_log ("received start message");
      break;

    default:
      break;
  }
}

/**
 * @brief Callback for tensor sink signal.
 */
static void
new_data_cb (GstElement * element, GstBuffer * buffer, gpointer user_data)
{
  if (recognizer.running) {
    GstMemory *mem;
    GstMapInfo info;
    guint i;
    guint num_mems;

    // _print_log ("received new-data!");

    num_mems = gst_buffer_n_memory (buffer);
    for (i = 0; i < num_mems; i++) {
      mem = gst_buffer_peek_memory (buffer, i);

      if (gst_memory_map (mem, &info, GST_MAP_READ)) {
        // _print_log ("received %d", (guint) info.size);
        update_top_label_index ((float *) info.data, (guint) info.size);
        gst_memory_unmap (mem, &info);
      }
    }
  }
}

/**
 * @brief Timer callback to update result.
 * @return True to ensure the timer continues
 */
static gboolean
timer_update_result_cb (gpointer user_data)
{
  gchar *label = NULL;
  GstElement *overlay;

  if (recognizer.running) {
    if (recognizer.new_label_index >= 0 &&
        recognizer.current_label_index != recognizer.new_label_index) {
      label =
          tflite_get_label (&recognizer.tflite_info,
          recognizer.new_label_index);
      _print_log ("speech command: %s", label);

      /* Pass detected speech command to application */
      if (recognizer_callbacks && recognizer_callbacks->command) {
        recognizer_callbacks->command (label);
      }

      /* update label */
      recognizer.current_label_index = recognizer.new_label_index;

      // TODO-21

    }
  }

  return TRUE;
}

static GstBusSyncReply
bus_sync_handler (GstBus * bus, GstMessage * message, gpointer user_data)
{
  switch (GST_MESSAGE_TYPE (message)) {
    case GST_MESSAGE_EOS:
      _print_log ("received eos message");
      break;

    case GST_MESSAGE_ERROR:
      _print_log ("received error message");
      parse_err_message (message);
      break;

    case GST_MESSAGE_WARNING:
      _print_log ("received warning message");
      parse_err_message (message);
      break;

    case GST_MESSAGE_STREAM_START:
      _print_log ("received start message");
      break;

    default:
      break;
  }

  // ignore anything but 'prepare-window-handle' element messages
  if (!gst_is_video_overlay_prepare_window_handle_message (message))
    return GST_BUS_PASS;

  if (recognizer.win_handle != 0) {
    GstVideoOverlay *overlay;

    _print_log ("bus_sync_handler");

    // GST_MESSAGE_SRC (message) will be the video sink element
    overlay = GST_VIDEO_OVERLAY (GST_MESSAGE_SRC (message));
    gst_video_overlay_set_window_handle (overlay, recognizer.win_handle);
  } else {
    g_warning ("Should have obtained video_window_handle by now!");
  }

  gst_message_unref (message);
  return GST_BUS_DROP;
}

gboolean
speech_recognizer_init (const char *argv1)
{
  const gchar alsa_device[] = "hw:0";
  const gchar tflite_model_path[] = "./speech_model";
  gchar *str_pipeline;
  gulong handle_id;
  GstElement *element;

  /* init app variable */
  recognizer.running = FALSE;

  recognizer.current_label_index = -1;
  recognizer.new_label_index = -1;
  recognizer.timer_id = 0;
  recognizer.win_handle = 0;
  recognizer.bus = 0;

  _check_cond_err (tflite_init_info (&recognizer.tflite_info,
          tflite_model_path));

  // TODO-18
  /* init pipeline */


  // /* bus and message callback */


  // /* Set the speech command pipeline's ximagesink to be drawn on the app window. */



  // TODO-19
  /* tensor sink signal : new data callback */


  // TODO-20
  /* timer to update result */


  recognizer.running = TRUE;

  /* audio src info */
  if (DBG) {
    gchar *audio_dev = NULL;
    gchar *dev_name = NULL;
    gchar *card_name = NULL;

    element = gst_bin_get_by_name (GST_BIN (recognizer.pipeline), "audio_src");

    g_object_get (element, "device", &audio_dev, NULL);
    g_object_get (element, "device-name", &dev_name, NULL);
    g_object_get (element, "card-name", &card_name, NULL);

    _print_log ("device [%s]", GST_STR_NULL (audio_dev));
    _print_log ("device name [%s]", GST_STR_NULL (dev_name));
    _print_log ("card name [%s]", GST_STR_NULL (card_name));

    gst_object_unref (element);
  }

  return TRUE;

error:
  _print_log ("error initializing speech recognizer!");

  speech_recognizer_finalize ();

  return FALSE;
}

void
speech_recognizer_finalize ()
{
  recognizer.running = FALSE;
  if (recognizer.pipeline)
    gst_element_set_state (recognizer.pipeline, GST_STATE_NULL);

  free_app_data ();
}

void
speech_recognizer_install_callbacks (SpeechRecognizerCallbacks * callbacks,
    gpointer user_data)
{
  recognizer_callbacks = callbacks;
}

void
speech_recognizer_set_window_handle (guintptr handle)
{
  recognizer.win_handle = handle;
}

void
speech_recognizer_start ()
{
  /* start pipeline */
  if (recognizer.pipeline)
    gst_element_set_state (recognizer.pipeline, GST_STATE_PLAYING);
}
